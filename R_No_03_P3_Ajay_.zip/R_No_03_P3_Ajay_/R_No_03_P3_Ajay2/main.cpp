#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <random>

using namespace std;

struct WeatherRecord {
    string date;
    string city;
    string state;
    double minTemp;
};

long long comparisons = 0;
long long assignments = 0;

string cleanToken(string s) {
    if (!s.empty() && s.front() == '"') s.erase(0, 1);
    if (!s.empty() && s.back() == '"') s.pop_back();

    size_t start = s.find_first_not_of(" \t");
    size_t end   = s.find_last_not_of(" \t");

    if (start == string::npos) return "";
    return s.substr(start, end - start + 1);
}

bool parseDouble(const string& s, double& value) {
    stringstream ss(s);
    ss >> value;
    return !ss.fail();
}

vector<WeatherRecord> loadData(const string& fileName) {
    vector<WeatherRecord> data;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "Cannot open weather.csv\n";
        return data;
    }

    string line;
    getline(file, line);

    while (getline(file, line)) {

        string token, date, city, state;
        double minTemp = 0.0;
        bool validTemp = false;

        stringstream ss(line);
        int col = 0;

        while (getline(ss, token, ',')) {
            token = cleanToken(token);

            if (col == 1) date = token;
            if (col == 5) city = token;
            if (col == 8) state = token;
            if (col == 11) validTemp = parseDouble(token, minTemp);

            col++;
        }

        if (!city.empty() && validTemp) {
            data.push_back({date, city, state, minTemp});
        }
    }

    return data;
}

bool comesBefore(const WeatherRecord& a, const WeatherRecord& b) {
    comparisons++;

    if (a.minTemp < b.minTemp) return true;
    if (a.minTemp > b.minTemp) return false;

    comparisons++;
    return a.city < b.city;
}

void merge(vector<WeatherRecord>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    vector<WeatherRecord> L(n1);
    vector<WeatherRecord> R(n2);

    for (int i = 0; i < n1; i++) {
        L[i] = arr[left + i];
        assignments++;
    }

    for (int j = 0; j < n2; j++) {
        R[j] = arr[mid + 1 + j];
        assignments++;
    }

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        if (comesBefore(L[i], R[j])) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
        assignments++;
    }

    while (i < n1) {
        arr[k++] = L[i++];
        assignments++;
    }

    while (j < n2) {
        arr[k++] = R[j++];
        assignments++;
    }
}

void mergeSort(vector<WeatherRecord>& arr, int left, int right) {
    if (left >= right) return;

    int mid = left + (right - left) / 2;

    mergeSort(arr, left, mid);
    mergeSort(arr, mid + 1, right);
    merge(arr, left, mid, right);
}

void writeOutput(ofstream& out,
                 const string& label,
                 const vector<WeatherRecord>& data) {

    out << label << "\n";
    out << "Date,City,State,MinTemp\n";

    for (const auto& r : data) {
        out << r.date << ","
            << r.city << ","
            << r.state << ","
            << r.minTemp << "\n";
    }

    out << "\n";
}

int main() {

    string inputFile = "../weather.csv";
    string outputFile = "../weather_output.txt";
    string resultFileName = "../results_weather_merge.csv";

    vector<WeatherRecord> fullData = loadData(inputFile);

    if (fullData.empty()) {
        cerr << "No valid records found. Check file path.\n";
        return 1;
    }

    ofstream output(outputFile);
    ofstream result(resultFileName);

    result << "N,Avg_Comparisons,Avg_Assignments\n";

    mt19937 rng(random_device{}());

    for (int n = 10; n <= 100; n += 10) {

        double totalC = 0;
        double totalA = 0;

        for (int i = 0; i < 10; ++i) {

            vector<WeatherRecord> sample;
            uniform_int_distribution<int> dist(0, fullData.size() - 1);

            for (int j = 0; j < n; ++j)
                sample.push_back(fullData[dist(rng)]);

            writeOutput(output,
                        "Before Sorting (n = " + to_string(n) + ")",
                        sample);

            comparisons = 0;
            assignments = 0;

            mergeSort(sample, 0, sample.size() - 1);

            writeOutput(output,
                        "After Sorting (n = " + to_string(n) + ")",
                        sample);

            totalC += comparisons;
            totalA += assignments;
        }

        result << n << ","
               << totalC / 10 << ","
               << totalA / 10 << "\n";
    }

    return 0;
}
