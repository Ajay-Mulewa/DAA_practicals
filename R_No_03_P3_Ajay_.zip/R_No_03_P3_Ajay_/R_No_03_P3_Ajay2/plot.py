import pandas as pd
import matplotlib.pyplot as plt

# Load CSV files
insertion = pd.read_csv("results_temp.csv")
merge = pd.read_csv("results_weather_merge.csv")

plt.figure()

# ---- Comparisons ----
plt.plot(insertion["N"],
         insertion["Avg_Comparisons"],
         marker='o',
         label="Insertion - Comparisons")

plt.plot(merge["N"],
         merge["Avg_Comparisons"],
         marker='o',
         linestyle='--',
         label="Merge - Comparisons")

# ---- Assignments ----
plt.plot(insertion["N"],
         insertion["Avg_Assignments"],
         marker='s',
         label="Insertion - Assignments")

plt.plot(merge["N"],
         merge["Avg_Assignments"],
         marker='s',
         linestyle='--',
         label="Merge - Assignments")

plt.xlabel("Input Size (N)")
plt.ylabel("Count")
plt.title("Insertion vs Merge Sort (Weather Data)")
plt.legend()
plt.grid(True)

plt.savefig("comparison_plot.png")
plt.show()
