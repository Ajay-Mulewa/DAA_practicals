import pandas as pd
import matplotlib.pyplot as plt


# ---------- Helper function for comparison ----------
def plot_compare(insertion_csv, merge_csv, title, output_image):
    ins = pd.read_csv(insertion_csv)
    mer = pd.read_csv(merge_csv)

    plt.figure()

    # Comparisons
    plt.plot(ins["N"], ins["Avg_Comparisons"],
             marker='o', label="Insertion - Comparisons")

    plt.plot(mer["N"], mer["Avg_Comparisons"],
             marker='o', linestyle='--',
             label="Merge - Comparisons")

    # Assignments
    plt.plot(ins["N"], ins["Avg_Assignments"],
             marker='s', label="Insertion - Assignments")

    plt.plot(mer["N"], mer["Avg_Assignments"],
             marker='s', linestyle='--',
             label="Merge - Assignments")

    plt.xlabel("Input Size (N)")
    plt.ylabel("Count")
    plt.title(title)
    plt.legend()
    plt.grid(True)

    plt.savefig(output_image)
    plt.close()


# ---------- Plot comparisons ----------

plot_compare(
    "results_age.csv",
    "results_age_merge.csv",
    "Insertion vs Merge Sort (By Age)",
    "compare_age.png"
)

plot_compare(
    "results_name.csv",
    "results_name_merge.csv",
    "Insertion vs Merge Sort (By Name)",
    "compare_name.png"
)

plot_compare(
    "results_age_name.csv",
    "results_age_name_merge.csv",
    "Insertion vs Merge Sort (By Age then Name)",
    "compare_age_name.png"
)