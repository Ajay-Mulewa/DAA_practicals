/**
 * @file main.cpp
 * @brief Practical 1 - testing Insertion sort
 *
 * (Person name and age) using three sorting criteria:
 *  1. By age
 *  2. By name
 *  3. By age, then by name
 *
 * For each n = 10, 20, ..., 100:
 *  - 10 random datasets are generated internally
 *  - Each dataset is sorted using all three criteria
 *  - Average comparisons and assignments are recorded
 *
 * Output Files:
 * outputs of sorting
 *  - ageSorted.txt
 *  - nameSorted.txt
 *  - ageNameSorted.txt
 *  data about avg comparisons and assignments
 *  - results_age.csv
 *  - results_name.csv
 *  - results_age_name.csv
 */

#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <random>
#include <iostream>
#include <utility>

using namespace std;

//
double numComparisons = 0.0;
double numAssignments = 0.0;

/**
 * @class Person
 * @brief Represents a record with name and age
 */
class Person {
    double age;
    string name;

public:
    Person(double age, string name)
        : age(age), name(std::move(name)) {}

    [[nodiscard]] double getAge() const { return age; }
    [[nodiscard]] string getName() const { return name; }
};

/**
 * @brief Load person records from CSV file
 * @param fileName is where data resides
 */
vector<Person> loadDataFromFile(const string& fileName) {
    vector<Person> persons;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "Failed to open input file\n";
        return persons;
    }

    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {
        string name, ageStr;
        stringstream ss(line);
        getline(ss, name, ',');
        getline(ss, ageStr);

        if (!name.empty() && !ageStr.empty()) {
            persons.emplace_back(stod(ageStr), name);
        }
    }
    return persons;
}

/** Comparator: sort by age */
auto compareByAge = [](const Person& a, const Person& b) {
    return a.getAge() > b.getAge();
};

/** Comparator: sort by name */
auto compareByName = [](const Person& a, const Person& b) {
    return a.getName() > b.getName();
};

/** Comparator: sort by age, then name */
auto compareByAgeThenName = [](const Person& a, const Person& b) {
    if (a.getAge() != b.getAge())
        return a.getAge() > b.getAge();
    return a.getName() > b.getName();
};

/**
 * @brief Reset global counters
 */
void resetCounters() {
    numComparisons = 0.0;
    numAssignments = 0.0;
}

/**
 * @brief Insertion sort algorithm
 * @param data to be sorted
 * @param comp compartor to passed to decide what and how to compare
 */
template <typename Comparator>
void insertionSort(vector<Person>& data, Comparator comp) {
    const int n = data.size();

    for (int i = 1; i < n; ++i) {
        Person key = data[i];
        numAssignments++;

        int j = i - 1;
        while (j >= 0) {
            numComparisons++;
            if (!comp(data[j], key))
                break;

            data[j + 1] = data[j];
            numAssignments++;
            --j;
        }
        data[j + 1] = key;
        numAssignments++;
    }
}

/**
 * @brief Write sorted output (before/after sorting)
 * @param out fileStream to write on
 * @param text for printing before/after
 * @param persons unsorted or sorted container of person objects
 **/
void writeOutput(ofstream& out,
                 const string& text,
                 const vector<Person>& persons) {
    out << text << '\n';
    for (const auto& p : persons) {
        out << "Name: " << p.getName()
            << ", Age: " << p.getAge() << '\n';
    }
    out << '\n';
}

/**
 * @brief Perform one sorting run and return counters
 * @param original a copy of it is created, this one remains intact
 * @param n datasize(10, 20, 30, ..., 100)
 * @param label for printing by-name/age/ageAndName
 * @param comp comparator passed to insertionSort
 * @return number of comparisons and assignments in pair <comparison, assignments>
 */
template <typename Comparator>
pair<double, double>
runSortAndWrite(const vector<Person>& original,
                const int n,
                const string& label,
                Comparator comp,
                ofstream& out) {
    vector<Person> working = original;

    writeOutput(out,
        "Before sorting " + label + " (n = " + to_string(n) + ")",
        working);

    resetCounters();
    insertionSort(working, comp);

    writeOutput(out,
        "After sorting " + label + " (n = " + to_string(n) + ")",
        working);

    return {numComparisons, numAssignments};
}

/**
 * @brief Write CSV results(avg Comparisons and Assignments
 * @param out is output file on which results are written
 * @param headerWritten to check if header written or not
 * @param n datasize(10, 20, 30, ..., 100)
 * @param avgComp average comparisons
 * @param avgAssn average assignments
 */
void writeResults(ofstream& out,
                  bool& headerWritten,
                  const int n,
                  double avgComp,
                  double avgAssn) {
    if (!headerWritten) {
        out << "N,Avg_Comparisons,Avg_Assignments\n";
        headerWritten = true;
    }
    out << n << "," << avgComp << "," << avgAssn << "\n";
}

/**
 * @brief Generate a random number used inside performExperiment
 * @attention below
 * @param max size of allRecords data which is loaded from file IMPORTANT
 * @note above
 * @return random integer in range 0 to max - 1
 */
int randomIndex(const int max) {
    static mt19937 rng(random_device{}());
    uniform_int_distribution<int> dist(0, max - 1);
    return dist(rng);
}

/**
 * @brief Perform insertion sort 10 times for a given n loads fresh data for each iteration
 * populates new data every single iteration
 * have variables to for average number of comparisons and assignments
 * those have suffixes C stands for comparison variable and...
 */
void performExperiment(const vector<Person>& allRecords,
                       const int n,
                       ofstream& ageSorted,
                       ofstream& nameSorted,
                       ofstream& ageNameSorted,
                       ofstream& resAge,
                       ofstream& resName,
                       ofstream& resAgeName,
                       bool& ageHeader,
                       bool& nameHeader,
                       bool& ageNameHeader) {
    double ageC = 0, ageA = 0;
    double nameC = 0, nameA = 0;
    double ageNameC = 0, ageNameA = 0;

    for (int i = 0; i < 10; ++i) {
        vector<Person> dataset;
        for (int j = 0; j < n; ++j) {
            dataset.push_back(
                allRecords[randomIndex(allRecords.size())]
            );
        }

        auto [c1, a1] = runSortAndWrite(dataset, n, "by age",
                                        compareByAge, ageSorted);
        auto [c2, a2] = runSortAndWrite(dataset, n, "by name",
                                        compareByName, nameSorted);
        auto [c3, a3] = runSortAndWrite(dataset, n, "by age then name",
                                        compareByAgeThenName, ageNameSorted);

        ageC += c1;      ageA += a1;
        nameC += c2;     nameA += a2;
        ageNameC += c3; ageNameA += a3;
    }

    writeResults(resAge, ageHeader, n, ageC / 10, ageA / 10);
    writeResults(resName, nameHeader, n, nameC / 10, nameA / 10);
    writeResults(resAgeName, ageNameHeader, n, ageNameC / 10, ageNameA / 10);
}

/**
 * @brief Program entry point
 * extracts data from input file
 * creates all necessary files
 * runs experiment for each n(10, 20, 30,..., 100)
 */
int main() {
    vector<Person> allRecords = loadDataFromFile("../input.csv");

    if (allRecords.empty()) {
        cerr << "Input file has no data\n";
        return 1;
    }

    // output files to display records after sorting
    ofstream ageSorted("../ageSorted.txt", ios::app);
    ofstream nameSorted("../nameSorted.txt", ios::app);
    ofstream ageNameSorted("../ageNameSorted.txt", ios::app);

    // output files for storing avgComp and avgAssgn
    ofstream resultsAge("../results_age.csv");
    ofstream resultsName("../results_name.csv");
    ofstream resultsAgeName("../results_age_name.csv");

    bool ageHeader = false;
    bool nameHeader = false;
    bool ageNameHeader = false;

    for (int n = 10; n <= 100; n += 10) {
        performExperiment(allRecords, n,
                          ageSorted, nameSorted, ageNameSorted,
                          resultsAge, resultsName, resultsAgeName,
                          ageHeader, nameHeader, ageNameHeader);
    }

    return 0;
}