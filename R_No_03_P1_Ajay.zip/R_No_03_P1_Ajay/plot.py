import pandas as pd
import matplotlib.pyplot as plt

# ---------- Helper function ----------
def plot_one(csv_file, title, output_image):
    df = pd.read_csv(csv_file)

    plt.figure()
    plt.plot(df["N"], df["Avg_Comparisons"],
             marker='o', label="Comparisons")
    plt.plot(df["N"], df["Avg_Assignments"],
             marker='s', label="Assignments")

    plt.xlabel("Input Size (N)")
    plt.ylabel("Count")
    plt.title(title)
    plt.legend()
    plt.grid(True)

    plt.savefig(output_image)
    plt.close()


# ---------- Plot for each sorting method ----------
plot_one(
    "results_age.csv",
    "Insertion Sort by Age",
    "age_plot.png"
)

plot_one(
    "results_name.csv",
    "Insertion Sort by Name",
    "name_plot.png"
)

plot_one(
    "results_age_name.csv",
    "Insertion Sort by Age then Name",
    "age_name_plot.png"
)