/**
 * @file main.cpp
 * @brief Practical 2 – Performance analysis of Insertion Sort on city temperature data
 *
 * This program performs an experimental analysis of the Insertion Sort algorithm
 * using real-world city temperature records. Each record consists of a city name
 * and its corresponding temperature.
 *
 * Sorting Criteria:
 *  - Primary key   : Temperature (ascending order)
 *  - Secondary key : City name (lexicographical order, if temperatures are equal)
 *
 * Experimental Setup:
 *  - Dataset sizes n = 10, 20, 30, ..., 100
 *  - For each n, 10 random datasets are generated internally
 *  - Insertion sort is applied to each dataset
 *  - Number of comparisons and assignments are recorded
 *  - Average values are computed for each n
 *
 * Output Files:
 *  - citySorted.txt     : Displays data before and after sorting
 *  - results_temp.csv   : Stores average comparisons and assignments
 *
 * Notes:
 *  - The program is fully automated
 *  - Insertion Sort is implemented manually (no STL sort)
 *  - File I/O time is excluded from algorithm performance analysis
 */

#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <random>
#include <iostream>
#include <utility>

using namespace std;

/**
 * @brief Global counters used to measure algorithm performance
 *
 * numComparisons  : Counts total key comparisons during sorting
 * numAssignments  : Counts total data movements (assignments)
 */
double numComparisons = 0.0;
double numAssignments = 0.0;

/**
 * @class CityTemp
 * @brief Represents a city temperature record
 *
 * Stores the name of a city and its associated temperature.
 * Objects of this class are used as elements for sorting.
 */
class CityTemp {
    string city;
    double temperature;

public:
    CityTemp(string city, double temperature)
        : city(std::move(city)), temperature(temperature) {}

    [[nodiscard]] string getCity() const { return city; }
    [[nodiscard]] double getTemperature() const { return temperature; }
};

/**
 * @brief Load city temperature records from a CSV file
 *
 * Reads city and temperature values from the given CSV file.
 * The first line (header) is ignored.
 *
 * @param fileName Path to the CSV input file
 * @return Vector containing all valid CityTemp records
 */
vector<CityTemp> loadDataFromFile(const string& fileName) {
    vector<CityTemp> data;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "Failed to open city_temp.csv\n";
        return data;
    }

    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {
        string city, tempStr;
        stringstream ss(line);

        getline(ss, city, ',');
        getline(ss, tempStr);

        if (!city.empty() && !tempStr.empty()) {
            data.emplace_back(city, stod(tempStr));
        }
    }
    return data;
}

/**
 * @brief Comparator for sorting by temperature, then by city name
 *
 * Sorting Order:
 *  - Lower temperature first
 *  - If temperatures are equal, cities are compared lexicographically
 */
auto compareByTempThenCity = [](const CityTemp& a, const CityTemp& b) {
    if (a.getTemperature() != b.getTemperature())
        return a.getTemperature() > b.getTemperature();
    return a.getCity() > b.getCity();
};

/**
 * @brief Reset global comparison and assignment counters
 *
 * This function is called before each sorting run to ensure
 * accurate performance measurements.
 */
void resetCounters() {
    numComparisons = 0.0;
    numAssignments = 0.0;
}

/**
 * @brief Insertion Sort implementation with performance counting
 *
 * Sorts the given dataset using the insertion sort algorithm.
 * Counts the number of comparisons and assignments performed.
 *
 * @tparam Comparator Comparison function type
 * @param data Vector of CityTemp objects to be sorted
 * @param comp Comparator defining the sorting rule
 */
template <typename Comparator>
void insertionSort(vector<CityTemp>& data, Comparator comp) {
    int n = data.size();

    for (int i = 1; i < n; ++i) {
        CityTemp key = data[i];
        numAssignments++;

        int j = i - 1;
        while (j >= 0) {
            numComparisons++;
            if (!comp(data[j], key))
                break;

            data[j + 1] = data[j];
            numAssignments++;
            --j;
        }
        data[j + 1] = key;
        numAssignments++;
    }
}

/**
 * @brief Write dataset contents to output file
 *
 * Writes a label followed by city-temperature pairs.
 * Used to display dataset state before and after sorting.
 *
 * @param out Output file stream
 * @param text Descriptive text (e.g., Before/After sorting)
 * @param data Dataset to be written
 */
void writeOutput(ofstream& out,
                 const string& text,
                 const vector<CityTemp>& data) {
    out << text << '\n';
    for (const auto& c : data) {
        out << c.getCity() << ", " << c.getTemperature() << '\n';
    }
    out << '\n';
}

/**
 * @brief Write average performance results to CSV file
 *
 * Writes dataset size along with average number of comparisons
 * and assignments. The CSV header is written only once.
 *
 * @param out Output CSV file stream
 * @param headerWritten Flag to track header status
 * @param n Dataset size
 * @param avgComp Average comparisons
 * @param avgAssn Average assignments
 */
void writeResults(ofstream& out,
                  bool& headerWritten,
                  int n,
                  double avgComp,
                  double avgAssn) {
    if (!headerWritten) {
        out << "N,Avg_Comparisons,Avg_Assignments\n";
        headerWritten = true;
    }
    out << n << "," << avgComp << "," << avgAssn << "\n";
}

/**
 * @brief Generate a random valid index
 *
 * Used to randomly sample records from the full dataset
 * while constructing experimental subsets.
 *
 * @param max Size of the source dataset
 * @return Random integer in range [0, max - 1]
 */
int randomIndex(int max) {
    static mt19937 rng(random_device{}());
    uniform_int_distribution<int> dist(0, max - 1);
    return dist(rng);
}

/**
 * @brief Perform insertion sort experiment for a given dataset size
 *
 * For the given value of n:
 *  - Generates 10 random datasets
 *  - Applies insertion sort to each dataset
 *  - Records total comparisons and assignments
 *  - Computes and stores average values
 *
 * @param allData Complete dataset loaded from file
 * @param n Size of dataset to be tested
 * @param outSorted File for before/after sorting output
 * @param outResults CSV file for averaged results
 * @param headerWritten Flag to control CSV header writing
 */
void performExperiment(const vector<CityTemp>& allData,
                       int n,
                       ofstream& outSorted,
                       ofstream& outResults,
                       bool& headerWritten) {
    double totalComp = 0.0;
    double totalAssn = 0.0;

    for (int i = 0; i < 10; ++i) {
        vector<CityTemp> dataset;
        for (int j = 0; j < n; ++j) {
            dataset.push_back(
                allData[randomIndex(allData.size())]
            );
        }

        writeOutput(outSorted,
            "Before sorting (n = " + to_string(n) + ")", dataset);

        resetCounters();
        insertionSort(dataset, compareByTempThenCity);

        writeOutput(outSorted,
            "After sorting (n = " + to_string(n) + ")", dataset);

        totalComp += numComparisons;
        totalAssn += numAssignments;
    }

    writeResults(outResults,
                 headerWritten,
                 n,
                 totalComp / 10,
                 totalAssn / 10);
}

/**
 * @brief Program entry point
 *
 * Loads city temperature data, initializes output files,
 * and performs insertion sort experiments for dataset sizes
 * ranging from 10 to 100.
 *
 * @return Exit status (0 for success, non-zero for failure)
 */
int main() {
    vector<CityTemp> allData = loadDataFromFile("../city_temp.csv");

    if (allData.empty()) {
        cerr << "No data found in city_temp.csv\n";
        return 1;
    }

    ofstream sortedOut("../citySorted.txt", ios::app);
    ofstream resultsOut("../results_temp.csv");

    bool headerWritten = false;

    for (int n = 10; n <= 100; n += 10) {
        performExperiment(allData, n,
                          sortedOut,
                          resultsOut,
                          headerWritten);
    }

    return 0;
}