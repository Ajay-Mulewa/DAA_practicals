import pandas as pd
import matplotlib.pyplot as plt

# Load results
df = pd.read_csv("results_temp.csv")

plt.figure()
plt.plot(df["N"], df["Avg_Comparisons"],
         marker='o', label="Comparisons")
plt.plot(df["N"], df["Avg_Assignments"],
         marker='s', label="Assignments")

plt.xlabel("Input Size (N)")
plt.ylabel("Count")
plt.title("Insertion Sort on Temperature Data")
plt.legend()
plt.grid(True)

plt.savefig("temperature_sort_plot.png")
plt.close()