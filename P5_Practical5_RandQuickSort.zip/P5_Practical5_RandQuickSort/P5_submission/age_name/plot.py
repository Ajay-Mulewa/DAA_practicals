"""
Practical 5 - Plot: Randomized Quick Sort vs Quick Sort vs Merge Sort vs Insertion Sort
(Name/Age dataset)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from numpy.polynomial import polynomial as P

def best_fit(x, y, label, color, ax):
    """Plot data points and an n log n best-fit curve."""
    ax.plot(x, y, 'o-', label=label, color=color)
    # Fit y = a * x * log(x) + b
    xl = x * np.log(x)
    coeffs = np.polyfit(xl, y, 1)
    yfit = np.polyval(coeffs, xl)
    ax.plot(x, yfit, '--', color=color, alpha=0.5)

# -------- Load all CSVs --------
age_ins  = pd.read_csv("results_age.csv")
age_mer  = pd.read_csv("results_age_merge.csv")
age_qui  = pd.read_csv("results_age_quick.csv")
age_rqui = pd.read_csv("results_age_rquick.csv")

name_ins  = pd.read_csv("results_name.csv")
name_mer  = pd.read_csv("results_name_merge.csv")
name_qui  = pd.read_csv("results_name_quick.csv")
name_rqui = pd.read_csv("results_name_rquick.csv")

an_ins  = pd.read_csv("results_age_name.csv")
an_mer  = pd.read_csv("results_age_name_merge.csv")
an_qui  = pd.read_csv("results_age_name_quick.csv")
an_rqui = pd.read_csv("results_age_name_rquick.csv")

COLORS = {
    'Insertion':          '#e74c3c',
    'Merge':              '#3498db',
    'Quick':              '#2ecc71',
    'Randomized Quick':   '#9b59b6',
}

# ============================================================
# FIGURE 1 — Sort by Age: Comparisons
# ============================================================
fig, ax = plt.subplots(figsize=(9, 5))
x = age_ins['N'].values.astype(float)

for (df, lbl) in [(age_ins,'Insertion'), (age_mer,'Merge'),
                  (age_qui,'Quick'), (age_rqui,'Randomized Quick')]:
    best_fit(df['N'].values.astype(float),
             df['Avg_Comparisons'].values,
             lbl, COLORS[lbl], ax)

ax.set_xlabel("n (dataset size)")
ax.set_ylabel("Avg Comparisons")
ax.set_title("P5: Sort by Age — Comparisons (all 4 algorithms)")
ax.legend()
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("comparison_age.png", dpi=150)
plt.close()
print("Saved comparison_age.png")

# ============================================================
# FIGURE 2 — Sort by Name: Comparisons
# ============================================================
fig, ax = plt.subplots(figsize=(9, 5))

for (df, lbl) in [(name_ins,'Insertion'), (name_mer,'Merge'),
                  (name_qui,'Quick'), (name_rqui,'Randomized Quick')]:
    best_fit(df['N'].values.astype(float),
             df['Avg_Comparisons'].values,
             lbl, COLORS[lbl], ax)

ax.set_xlabel("n (dataset size)")
ax.set_ylabel("Avg Comparisons")
ax.set_title("P5: Sort by Name — Comparisons (all 4 algorithms)")
ax.legend()
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("comparison_name.png", dpi=150)
plt.close()
print("Saved comparison_name.png")

# ============================================================
# FIGURE 3 — Sort by Age then Name: Comparisons
# ============================================================
fig, ax = plt.subplots(figsize=(9, 5))

for (df, lbl) in [(an_ins,'Insertion'), (an_mer,'Merge'),
                  (an_qui,'Quick'), (an_rqui,'Randomized Quick')]:
    best_fit(df['N'].values.astype(float),
             df['Avg_Comparisons'].values,
             lbl, COLORS[lbl], ax)

ax.set_xlabel("n (dataset size)")
ax.set_ylabel("Avg Comparisons")
ax.set_title("P5: Sort by Age+Name — Comparisons (all 4 algorithms)")
ax.legend()
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("comparison_age_name.png", dpi=150)
plt.close()
print("Saved comparison_age_name.png")

# ============================================================
# FIGURE 4 — Quick vs Randomized Quick: side-by-side (Age)
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

# Comparisons
axes[0].plot(age_qui['N'],  age_qui['Avg_Comparisons'],  'o-',
             label='Quick Sort',            color=COLORS['Quick'])
axes[0].plot(age_rqui['N'], age_rqui['Avg_Comparisons'], 's--',
             label='Randomized Quick Sort', color=COLORS['Randomized Quick'])
axes[0].set_title("Comparisons — Sort by Age")
axes[0].set_xlabel("n"); axes[0].set_ylabel("Avg Comparisons")
axes[0].legend(); axes[0].grid(alpha=0.3)

# Assignments
axes[1].plot(age_qui['N'],  age_qui['Avg_Assignments'],  'o-',
             label='Quick Sort',            color=COLORS['Quick'])
axes[1].plot(age_rqui['N'], age_rqui['Avg_Assignments'], 's--',
             label='Randomized Quick Sort', color=COLORS['Randomized Quick'])
axes[1].set_title("Assignments — Sort by Age")
axes[1].set_xlabel("n"); axes[1].set_ylabel("Avg Assignments")
axes[1].legend(); axes[1].grid(alpha=0.3)

plt.suptitle("P5: Quick Sort vs Randomized Quick Sort (Age)", fontsize=13)
plt.tight_layout()
plt.savefig("quick_vs_rquick_age.png", dpi=150)
plt.close()
print("Saved quick_vs_rquick_age.png")

print("\nAll plots saved successfully.")
