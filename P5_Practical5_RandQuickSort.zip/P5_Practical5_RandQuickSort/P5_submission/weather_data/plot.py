"""
Practical 5 - Plot: Randomized Quick Sort vs Quick Sort vs Merge Sort vs Insertion Sort
(Weather dataset)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def best_fit_line(x, y, ax, color):
    xl = x * np.log(x)
    coeffs = np.polyfit(xl, y, 1)
    ax.plot(x, np.polyval(coeffs, xl), '--', color=color, alpha=0.45)

COLORS = {
    'Insertion':        '#e74c3c',
    'Merge':            '#3498db',
    'Quick':            '#2ecc71',
    'Randomized Quick': '#9b59b6',
}

# -------- Load data --------
ins   = pd.read_csv("results_temp_insertion.csv")
mer   = pd.read_csv("results_weather_merge.csv")
qui   = pd.read_csv("results_weather_quick.csv")
rqui  = pd.read_csv("results_weather_rquick.csv")

datasets = [
    (ins,  'Insertion'),
    (mer,  'Merge'),
    (qui,  'Quick'),
    (rqui, 'Randomized Quick'),
]

# ============================================================
# FIGURE 1 — All 4: Comparisons
# ============================================================
fig, ax = plt.subplots(figsize=(9, 5))

for df, lbl in datasets:
    x = df['N'].values.astype(float)
    y = df['Avg_Comparisons'].values
    ax.plot(x, y, 'o-', label=lbl, color=COLORS[lbl])
    best_fit_line(x, y, ax, COLORS[lbl])

ax.set_xlabel("n (sample size)")
ax.set_ylabel("Avg Comparisons")
ax.set_title("P5: Weather Data — Comparisons (all 4 algorithms)")
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("weather_all_comparison.png", dpi=150)
plt.close()
print("Saved weather_all_comparison.png")

# ============================================================
# FIGURE 2 — All 4: Assignments
# ============================================================
fig, ax = plt.subplots(figsize=(9, 5))

for df, lbl in datasets:
    x = df['N'].values.astype(float)
    y = df['Avg_Assignments'].values
    ax.plot(x, y, 'o-', label=lbl, color=COLORS[lbl])
    best_fit_line(x, y, ax, COLORS[lbl])

ax.set_xlabel("n (sample size)")
ax.set_ylabel("Avg Assignments")
ax.set_title("P5: Weather Data — Assignments (all 4 algorithms)")
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("weather_all_assignments.png", dpi=150)
plt.close()
print("Saved weather_all_assignments.png")

# ============================================================
# FIGURE 3 — Quick vs Randomized Quick only
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

for metric, idx, ylabel in [('Avg_Comparisons', 0, 'Avg Comparisons'),
                              ('Avg_Assignments',  1, 'Avg Assignments')]:
    axes[idx].plot(qui['N'],  qui[metric],  'o-',
                   label='Quick Sort',            color=COLORS['Quick'])
    axes[idx].plot(rqui['N'], rqui[metric], 's--',
                   label='Randomized Quick Sort', color=COLORS['Randomized Quick'])
    axes[idx].set_xlabel("n")
    axes[idx].set_ylabel(ylabel)
    axes[idx].set_title(f"Weather: {ylabel}")
    axes[idx].legend(); axes[idx].grid(alpha=0.3)

plt.suptitle("P5: Quick Sort vs Randomized Quick Sort — Weather Data", fontsize=13)
plt.tight_layout()
plt.savefig("quick_vs_rquick_weather.png", dpi=150)
plt.close()
print("Saved quick_vs_rquick_weather.png")

print("\nAll plots saved successfully.")
