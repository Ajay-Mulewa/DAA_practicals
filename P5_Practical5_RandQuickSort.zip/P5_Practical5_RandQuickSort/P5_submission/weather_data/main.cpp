/**
 * @file main.cpp
 * @brief Practical 5 - Real-life Application: Weather Data (Randomized Quick Sort)
 *
 * Sorts WeatherRecord data (minTemp, city) using Randomized Quick Sort.
 * Compares results with Insertion Sort, Merge Sort, and Quick Sort from P1-P4.
 *
 * Key difference from Practical 4 (deterministic Quick Sort):
 *  - Pivot selected RANDOMLY in [low, high] before each partition step
 *  - Prevents worst-case O(n^2) on adversarial / pre-sorted data
 *
 * Output Files:
 *  - weather_output.txt         (before/after snapshots)
 *  - results_weather_rquick.csv (N, Avg_Comparisons, Avg_Assignments)
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <random>

using namespace std;

/* ===================== DATA ===================== */

struct WeatherRecord {
    string date;
    string city;
    string state;
    double minTemp;
};

long long comparisons = 0;
long long assignments = 0;

/* ===================== RANDOM ENGINE ===================== */

mt19937& getRNG() {
    static mt19937 rng(random_device{}());
    return rng;
}

/* ===================== HELPERS ===================== */

string cleanToken(string s) {
    if (!s.empty() && s.front() == '"') s.erase(0, 1);
    if (!s.empty() && s.back()  == '"') s.pop_back();
    size_t start = s.find_first_not_of(" \t");
    size_t end   = s.find_last_not_of(" \t");
    if (start == string::npos) return "";
    return s.substr(start, end - start + 1);
}

bool parseDouble(const string& s, double& value) {
    stringstream ss(s);
    ss >> value;
    return !ss.fail();
}

/* ===================== FILE LOAD ===================== */

vector<WeatherRecord> loadData(const string& fileName) {
    vector<WeatherRecord> data;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "Cannot open " << fileName << "\n";
        return data;
    }

    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {
        string token, date, city, state;
        double minTemp = 0.0;
        bool validTemp = false;

        stringstream ss(line);
        int col = 0;

        while (getline(ss, token, ',')) {
            token = cleanToken(token);
            if (col == 1)  date     = token;
            if (col == 5)  city     = token;
            if (col == 8)  state    = token;
            if (col == 11) validTemp = parseDouble(token, minTemp);
            col++;
        }

        if (!city.empty() && validTemp)
            data.push_back({date, city, state, minTemp});
    }

    return data;
}

/* ===================== COMPARATOR ===================== */

bool comesBefore(const WeatherRecord& a, const WeatherRecord& b) {
    comparisons++;
    if (a.minTemp < b.minTemp) return true;
    if (a.minTemp > b.minTemp) return false;
    comparisons++;
    return a.city < b.city;
}

/* ===================== RANDOMIZED QUICK SORT =====================
 *
 * randomizedPartition():
 *   1. Pick a uniformly random index `pivotIdx` in [low, high].
 *   2. Swap data[pivotIdx] with data[high].
 *   3. Run the standard Lomuto scheme with data[high] as pivot.
 *
 * This single change makes worst-case O(n^2) inputs impossible to
 * construct in advance, guaranteeing O(n log n) expected comparisons
 * regardless of input order.
 * ================================================================ */

int randomizedPartition(vector<WeatherRecord>& arr, int low, int high) {

    // Step 1: random pivot
    uniform_int_distribution<int> dist(low, high);
    int pivotIdx = dist(getRNG());

    // Step 2: move pivot to last position
    swap(arr[pivotIdx], arr[high]);
    assignments += 3;

    // Step 3: standard Lomuto partition
    WeatherRecord pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        comparisons++;
        if (comesBefore(arr[j], pivot)) {
            i++;
            swap(arr[i], arr[j]);
            assignments += 3;
        }
    }

    swap(arr[i + 1], arr[high]);
    assignments += 3;

    return i + 1;
}

void randomizedQuickSort(vector<WeatherRecord>& arr, int low, int high) {
    if (low < high) {
        int pi = randomizedPartition(arr, low, high);
        randomizedQuickSort(arr, low, pi - 1);
        randomizedQuickSort(arr, pi + 1, high);
    }
}

/* ===================== OUTPUT ===================== */

void writeOutput(ofstream& out,
                 const string& label,
                 const vector<WeatherRecord>& data) {
    out << label << "\n";
    out << "Date,City,State,MinTemp\n";
    for (const auto& r : data)
        out << r.date << "," << r.city << ","
            << r.state << "," << r.minTemp << "\n";
    out << "\n";
}

/* ===================== MAIN ===================== */

int main() {

    string inputFile    = "weather.csv";
    string outputFile   = "weather_output.txt";
    string resultFile   = "results_weather_rquick.csv";

    vector<WeatherRecord> fullData = loadData(inputFile);

    if (fullData.empty()) {
        cerr << "No valid records found. Check file path.\n";
        return 1;
    }

    ofstream output(outputFile);
    ofstream result(resultFile);

    result << "N,Avg_Comparisons,Avg_Assignments\n";

    for (int n = 10; n <= 100; n += 10) {

        double totalC = 0, totalA = 0;

        for (int i = 0; i < 10; ++i) {

            vector<WeatherRecord> sample;
            uniform_int_distribution<int> dist(0, (int)fullData.size() - 1);
            for (int j = 0; j < n; ++j)
                sample.push_back(fullData[dist(getRNG())]);

            writeOutput(output,
                        "Before Sorting (n = " + to_string(n) + ")",
                        sample);

            comparisons = 0;
            assignments = 0;

            randomizedQuickSort(sample, 0, (int)sample.size() - 1);

            writeOutput(output,
                        "After Sorting (n = " + to_string(n) + ")",
                        sample);

            totalC += comparisons;
            totalA += assignments;
        }

        result << n << ","
               << totalC / 10 << ","
               << totalA / 10 << "\n";
    }

    cout << "Done. Results in " << resultFile << "\n";
    return 0;
}
