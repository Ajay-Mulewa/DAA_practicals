"""
Practical 6 - Plot: Radix Sort time vs Insertion / Merge / Quick / Randomized Quick
"""

import pandas as pd
import matplotlib.pyplot as plt

# -------- Load timing CSVs (produced by main.cpp) --------
age      = pd.read_csv("results_time_age.csv")
name     = pd.read_csv("results_time_name.csv")
age_name = pd.read_csv("results_time_age_name.csv")

COLS = [
    ('Insertion_ns',  'Insertion',        '#e74c3c'),
    ('Merge_ns',      'Merge',            '#3498db'),
    ('Quick_ns',      'Quick',            '#2ecc71'),
    ('RandQuick_ns',  'Randomized Quick', '#9b59b6'),
    ('Radix_ns',      'Radix',            '#f39c12'),
]

# -------- AGE --------
plt.figure()
for col, lbl, color in COLS:
    plt.plot(age['N'], age[col], label=lbl, color=color)
plt.xlabel("N")
plt.ylabel("Avg Time (ns)")
plt.title("Sorting Time Comparison (Age)")
plt.legend()
plt.grid()
plt.savefig("time_age.png")
plt.close()

# -------- NAME --------
plt.figure()
for col, lbl, color in COLS:
    plt.plot(name['N'], name[col], label=lbl, color=color)
plt.xlabel("N")
plt.ylabel("Avg Time (ns)")
plt.title("Sorting Time Comparison (Name)")
plt.legend()
plt.grid()
plt.savefig("time_name.png")
plt.close()

# -------- AGE + NAME --------
plt.figure()
for col, lbl, color in COLS:
    plt.plot(age_name['N'], age_name[col], label=lbl, color=color)
plt.xlabel("N")
plt.ylabel("Avg Time (ns)")
plt.title("Sorting Time Comparison (Age + Name)")
plt.legend()
plt.grid()
plt.savefig("time_age_name.png")
plt.close()

print("Graphs saved as PNG files.")
