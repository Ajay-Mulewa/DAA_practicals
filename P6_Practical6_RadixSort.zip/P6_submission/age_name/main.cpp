/**
 * @file main.cpp
 * @brief Practical 6 - Radix Sort + timing comparison with P1-P5 algorithms
 *
 * Sorts (Person name, age) data using three sorting criteria:
 *  1. By age
 *  2. By name
 *  3. By age, then by name
 *
 * Data (per instructions):
 *  - Name : random string of exactly 10 lowercase letters
 *  - Age  : float in [10.0, 19.9], one decimal place
 *
 * For each n = 10, 20, ..., 100:
 *  - 10 random datasets are generated internally
 *  - Each dataset is sorted using all five algorithms
 *  - Average time (nanoseconds) is recorded
 *  - Note: comparisons/assignments are not counted for Radix Sort
 *
 * New in P6 — Radix Sort (LSD, stable counting sort per pass):
 *  By age      : age*10 -> int in [100,199]; 2 passes (units, tens digit)
 *  By name     : 10 passes (one per char position, right to left), radix = 26
 *  By age+name : sort by name first (10 passes), then by age (2 passes);
 *                stability preserves name order within equal ages
 *
 * Output Files:
 *  - ageSorted_output.txt
 *  - nameSorted_output.txt
 *  - ageNameSorted_output.txt
 *  - results_time_age.csv
 *  - results_time_name.csv
 *  - results_time_age_name.csv
 */

#include <vector>
#include <string>
#include <fstream>
#include <random>
#include <chrono>
#include <iostream>
#include <utility>
#include <cmath>

using namespace std;
using clk = chrono::high_resolution_clock;
using ns  = chrono::nanoseconds;

/* ===================== PERSON CLASS ===================== */

class Person {
    double age;
    string name;

public:
    Person(double age, string name)
        : age(age), name(std::move(name)) {}

    double getAge()  const { return age;  }
    string getName() const { return name; }
};

/* ===================== RANDOM ENGINE ===================== */

mt19937& getRNG() {
    static mt19937 rng(random_device{}());
    return rng;
}

/* ===================== SYNTHETIC DATA GENERATION =====================
 * Names: exactly 10 random lowercase letters
 * Age:   one decimal place in [10.0, 19.9]
 * ===================================================================== */

Person randomPerson() {
    uniform_int_distribution<int> letter('a', 'z');
    uniform_int_distribution<int> ageTenths(100, 199);

    string name(10, ' ');
    for (char& c : name) c = static_cast<char>(letter(getRNG()));

    return Person(ageTenths(getRNG()) / 10.0, name);
}

int randomIndex(const int max) {
    uniform_int_distribution<int> dist(0, max - 1);
    return dist(getRNG());
}

/* ===================== COMPARATORS ===================== */

auto compareByAge = [](const Person& a, const Person& b) {
    return a.getAge() > b.getAge();
};

auto compareByName = [](const Person& a, const Person& b) {
    return a.getName() > b.getName();
};

auto compareByAgeThenName = [](const Person& a, const Person& b) {
    if (a.getAge() != b.getAge())
        return a.getAge() > b.getAge();
    return a.getName() > b.getName();
};

/* ===================== OUTPUT ===================== */

void writeOutput(ofstream& out,
                 const string& text,
                 const vector<Person>& persons) {
    out << text << '\n';
    for (const auto& p : persons)
        out << "Name: " << p.getName()
            << ", Age: " << p.getAge() << '\n';
    out << '\n';
}

void writeResults(ofstream& out,
                  bool& headerWritten,
                  const int n,
                  double avgIns,
                  double avgMer,
                  double avgQui,
                  double avgRQui,
                  double avgRad) {

    if (!headerWritten) {
        out << "N,Insertion_ns,Merge_ns,Quick_ns,RandQuick_ns,Radix_ns\n";
        headerWritten = true;
    }
    out << n << "," << avgIns  << "," << avgMer  << ","
             << avgQui << "," << avgRQui << "," << avgRad << "\n";
}

/* ===================== INSERTION SORT  (P1) ===================== */

template <typename Comparator>
void insertionSort(vector<Person>& data, Comparator comp) {
    for (int i = 1; i < (int)data.size(); ++i) {
        Person key = data[i];
        int j = i - 1;
        while (j >= 0 && comp(data[j], key)) {
            data[j + 1] = data[j];
            --j;
        }
        data[j + 1] = key;
    }
}

/* ===================== MERGE SORT  (P3) ===================== */

template <typename Comparator>
void merge(vector<Person>& data, int l, int m, int r, Comparator comp) {
    vector<Person> left(data.begin() + l, data.begin() + m + 1);
    vector<Person> right(data.begin() + m + 1, data.begin() + r + 1);
    int i = 0, j = 0, k = l;
    while (i < (int)left.size() && j < (int)right.size())
        data[k++] = comp(left[i], right[j]) ? left[i++] : right[j++];
    while (i < (int)left.size())  data[k++] = left[i++];
    while (j < (int)right.size()) data[k++] = right[j++];
}

template <typename Comparator>
void mergeSort(vector<Person>& data, int l, int r, Comparator comp) {
    if (l >= r) return;
    int m = (l + r) / 2;
    mergeSort(data, l, m, comp);
    mergeSort(data, m + 1, r, comp);
    merge(data, l, m, r, comp);
}

/* ===================== QUICK SORT  (P4) ===================== */

template <typename Comparator>
int partition(vector<Person>& data, int low, int high, Comparator comp) {
    Person pivot = data[high];
    int i = low - 1;
    for (int j = low; j < high; j++)
        if (!comp(data[j], pivot)) swap(data[++i], data[j]);
    swap(data[i + 1], data[high]);
    return i + 1;
}

template <typename Comparator>
void quickSort(vector<Person>& data, int low, int high, Comparator comp) {
    if (low < high) {
        int pi = partition(data, low, high, comp);
        quickSort(data, low, pi - 1, comp);
        quickSort(data, pi + 1, high, comp);
    }
}

/* ===================== RANDOMIZED QUICK SORT  (P5) ===================== */

template <typename Comparator>
int randomizedPartition(vector<Person>& data, int low, int high, Comparator comp) {
    uniform_int_distribution<int> dist(low, high);
    swap(data[dist(getRNG())], data[high]);
    return partition(data, low, high, comp);
}

template <typename Comparator>
void randomizedQuickSort(vector<Person>& data, int low, int high, Comparator comp) {
    if (low < high) {
        int pi = randomizedPartition(data, low, high, comp);
        randomizedQuickSort(data, low, pi - 1, comp);
        randomizedQuickSort(data, pi + 1, high, comp);
    }
}

/* ===================== RADIX SORT  (P6) =====================
 *
 * LSD (Least Significant Digit first) counting sort — stable at each pass.
 *
 * By age:
 *   age * 10 -> integer in [100, 199]
 *   Pass 0: units digit (% 10), Pass 1: tens digit (/ 10 % 10)
 *   Hundreds digit is always 1 — no ordering info, skip it.
 *
 * By name:
 *   Names are exactly 10 lowercase letters (radix 26).
 *   10 passes, character positions 9 down to 0.
 *
 * By age then name (composite):
 *   Sort by name first (secondary key, 10 passes),
 *   then sort by age  (primary   key,  2 passes).
 *   Stability of each counting pass preserves the secondary ordering.
 * ================================================================ */

template <typename KeyFn>
void countingPassStable(vector<Person>& v, KeyFn keyFn, int R) {
    int n = (int)v.size();
    vector<int> cnt(R, 0);
    for (const auto& p : v) cnt[keyFn(p)]++;
    for (int i = 1; i < R; ++i) cnt[i] += cnt[i - 1];
    vector<Person> out(n, Person(0, ""));
    for (int i = n - 1; i >= 0; --i) out[--cnt[keyFn(v[i])]] = v[i];
    v = move(out);
}

void radixSortAge(vector<Person>& v) {
    auto d0 = [](const Person& p){ return (int)round(p.getAge() * 10) % 10; };
    auto d1 = [](const Person& p){ return (int)round(p.getAge() * 10) / 10 % 10; };
    countingPassStable(v, d0, 10);
    countingPassStable(v, d1, 10);
}

void radixSortName(vector<Person>& v) {
    for (int pos = 9; pos >= 0; --pos) {
        auto key = [pos](const Person& p){ return p.getName()[pos] - 'a'; };
        countingPassStable(v, key, 26);
    }
}

void radixSortAgeName(vector<Person>& v) {
    // secondary key first
    for (int pos = 9; pos >= 0; --pos) {
        auto key = [pos](const Person& p){ return p.getName()[pos] - 'a'; };
        countingPassStable(v, key, 26);
    }
    // primary key second
    auto d0 = [](const Person& p){ return (int)round(p.getAge() * 10) % 10; };
    auto d1 = [](const Person& p){ return (int)round(p.getAge() * 10) / 10 % 10; };
    countingPassStable(v, d0, 10);
    countingPassStable(v, d1, 10);
}

/* ===================== RUN SORT + WRITE OUTPUT ===================== */

// Times one sort, writes before/after to output file, returns nanoseconds
template <typename SortFn>
long long runSortAndWrite(const vector<Person>& original,
                          const int n,
                          const string& label,
                          SortFn sortFn,
                          ofstream& out) {

    vector<Person> working = original;

    writeOutput(out, "Before sorting " + label + " (n = " + to_string(n) + ")", working);

    auto t0 = clk::now();
    sortFn(working);
    long long elapsed = chrono::duration_cast<ns>(clk::now() - t0).count();

    writeOutput(out, "After sorting " + label + " (n = " + to_string(n) + ")", working);

    return elapsed;
}

/* ===================== EXPERIMENT ===================== */

void performExperiment(const int n,
                       ofstream& ageSorted,
                       ofstream& nameSorted,
                       ofstream& ageNameSorted,
                       ofstream& resAge,
                       ofstream& resName,
                       ofstream& resAgeName,
                       bool& ageHeader,
                       bool& nameHeader,
                       bool& ageNameHeader) {

    double insAge = 0, merAge = 0, quiAge = 0, rquiAge = 0, radAge = 0;
    double insName = 0, merName = 0, quiName = 0, rquiName = 0, radName = 0;
    double insAN = 0,  merAN = 0,  quiAN = 0,  rquiAN = 0,  radAN = 0;

    for (int i = 0; i < 10; ++i) {

        // generate fresh random dataset
        vector<Person> dataset;
        for (int j = 0; j < n; ++j)
            dataset.push_back(randomPerson());

        // --- sort by age ---
        insAge  += runSortAndWrite(dataset, n, "by age (Insertion)",       [](vector<Person>& v){ insertionSort(v, compareByAge); },                                   ageSorted);
        merAge  += runSortAndWrite(dataset, n, "by age (Merge)",           [](vector<Person>& v){ mergeSort(v, 0, (int)v.size()-1, compareByAge); },                   ageSorted);
        quiAge  += runSortAndWrite(dataset, n, "by age (Quick)",           [](vector<Person>& v){ quickSort(v, 0, (int)v.size()-1, compareByAge); },                   ageSorted);
        rquiAge += runSortAndWrite(dataset, n, "by age (Rand. Quick)",     [](vector<Person>& v){ randomizedQuickSort(v, 0, (int)v.size()-1, compareByAge); },         ageSorted);
        radAge  += runSortAndWrite(dataset, n, "by age (Radix)",           [](vector<Person>& v){ radixSortAge(v); },                                                  ageSorted);

        // --- sort by name ---
        insName  += runSortAndWrite(dataset, n, "by name (Insertion)",     [](vector<Person>& v){ insertionSort(v, compareByName); },                                  nameSorted);
        merName  += runSortAndWrite(dataset, n, "by name (Merge)",         [](vector<Person>& v){ mergeSort(v, 0, (int)v.size()-1, compareByName); },                  nameSorted);
        quiName  += runSortAndWrite(dataset, n, "by name (Quick)",         [](vector<Person>& v){ quickSort(v, 0, (int)v.size()-1, compareByName); },                  nameSorted);
        rquiName += runSortAndWrite(dataset, n, "by name (Rand. Quick)",   [](vector<Person>& v){ randomizedQuickSort(v, 0, (int)v.size()-1, compareByName); },        nameSorted);
        radName  += runSortAndWrite(dataset, n, "by name (Radix)",         [](vector<Person>& v){ radixSortName(v); },                                                 nameSorted);

        // --- sort by age then name ---
        insAN  += runSortAndWrite(dataset, n, "by age+name (Insertion)",   [](vector<Person>& v){ insertionSort(v, compareByAgeThenName); },                           ageNameSorted);
        merAN  += runSortAndWrite(dataset, n, "by age+name (Merge)",       [](vector<Person>& v){ mergeSort(v, 0, (int)v.size()-1, compareByAgeThenName); },           ageNameSorted);
        quiAN  += runSortAndWrite(dataset, n, "by age+name (Quick)",       [](vector<Person>& v){ quickSort(v, 0, (int)v.size()-1, compareByAgeThenName); },           ageNameSorted);
        rquiAN += runSortAndWrite(dataset, n, "by age+name (Rand. Quick)", [](vector<Person>& v){ randomizedQuickSort(v, 0, (int)v.size()-1, compareByAgeThenName); }, ageNameSorted);
        radAN  += runSortAndWrite(dataset, n, "by age+name (Radix)",       [](vector<Person>& v){ radixSortAgeName(v); },                                              ageNameSorted);
    }

    writeResults(resAge,     ageHeader,     n, insAge/10,  merAge/10,  quiAge/10,  rquiAge/10,  radAge/10);
    writeResults(resName,    nameHeader,    n, insName/10, merName/10, quiName/10, rquiName/10, radName/10);
    writeResults(resAgeName, ageNameHeader, n, insAN/10,   merAN/10,   quiAN/10,   rquiAN/10,   radAN/10);
}

/* ===================== MAIN ===================== */

int main() {

    ofstream ageSorted    ("ageSorted_output.txt",     ios::app);
    ofstream nameSorted   ("nameSorted_output.txt",    ios::app);
    ofstream ageNameSorted("ageNameSorted_output.txt", ios::app);

    ofstream resultsAge    ("results_time_age.csv");
    ofstream resultsName   ("results_time_name.csv");
    ofstream resultsAgeName("results_time_age_name.csv");

    bool ageHeader     = false;
    bool nameHeader    = false;
    bool ageNameHeader = false;

    for (int n = 10; n <= 100; n += 10) {
        performExperiment(n,
                          ageSorted, nameSorted, ageNameSorted,
                          resultsAge, resultsName, resultsAgeName,
                          ageHeader, nameHeader, ageNameHeader);
    }

    cout << "Done. Results written to:\n"
         << "  results_time_age.csv\n"
         << "  results_time_name.csv\n"
         << "  results_time_age_name.csv\n";

    return 0;
}
