/**
 * @file main.cpp
 * @brief Practical 3 - testing Merge sort (based on Practical 1)
 *
 * (Person name and age) using three sorting criteria:
 *  1. By age
 *  2. By name
 *  3. By age, then by name
 *
 * For each n = 10, 20, ..., 100:
 *  - 10 random datasets are generated internally
 *  - Each dataset is sorted using all three criteria
 *  - Average comparisons and assignments are recorded
 *
 * Output Files:
 *  - ageSorted_merge.txt
 *  - nameSorted_merge.txt
 *  - ageNameSorted_merge.txt
 *  - results_age_merge.csv
 *  - results_name_merge.csv
 *  - results_age_name_merge.csv
 */

#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <random>
#include <iostream>
#include <utility>

using namespace std;

double numComparisons = 0.0;
double numAssignments = 0.0;

class Person {
    double age;
    string name;

public:
    Person(double age, string name)
        : age(age), name(std::move(name)) {}

    double getAge() const { return age; }
    string getName() const { return name; }
};

vector<Person> loadDataFromFile(const string& fileName) {
    vector<Person> persons;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "Failed to open input file\n";
        return persons;
    }

    string line;
    getline(file, line);

    while (getline(file, line)) {
        string name, ageStr;
        stringstream ss(line);
        getline(ss, name, ',');
        getline(ss, ageStr);

        if (!name.empty() && !ageStr.empty()) {
            persons.emplace_back(stod(ageStr), name);
        }
    }
    return persons;
}

/* Comparators */

auto compareByAge = [](const Person& a, const Person& b) {
    numComparisons++;
    return a.getAge() > b.getAge();
};

auto compareByName = [](const Person& a, const Person& b) {
    numComparisons++;
    return a.getName() > b.getName();
};

auto compareByAgeThenName = [](const Person& a, const Person& b) {
    numComparisons++;
    if (a.getAge() != b.getAge())
        return a.getAge() > b.getAge();
    numComparisons++;
    return a.getName() > b.getName();
};

void resetCounters() {
    numComparisons = 0.0;
    numAssignments = 0.0;
}

/* ===================== QUICK SORT ===================== */

template <typename Comparator>
int partition(vector<Person>& data,
              int low,
              int high,
              Comparator comp) {

    Person pivot = data[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {

        numComparisons++;
        if (!comp(data[j], pivot)) {

            i++;
            swap(data[i], data[j]);
            numAssignments += 3;
        }
    }

    swap(data[i + 1], data[high]);
    numAssignments += 3;

    return i + 1;
}

template <typename Comparator>
void quickSort(vector<Person>& data,
               int low,
               int high,
               Comparator comp) {

    if (low < high) {

        int pi = partition(data, low, high, comp);

        quickSort(data, low, pi - 1, comp);
        quickSort(data, pi + 1, high, comp);
    }
}

/* ===================== OUTPUT ===================== */

void writeOutput(ofstream& out,
                 const string& text,
                 const vector<Person>& persons) {
    out << text << '\n';
    for (const auto& p : persons) {
        out << "Name: " << p.getName()
            << ", Age: " << p.getAge() << '\n';
    }
    out << '\n';
}

template <typename Comparator>
pair<double, double>
runSortAndWrite(const vector<Person>& original,
                const int n,
                const string& label,
                Comparator comp,
                ofstream& out) {

    vector<Person> working = original;

    writeOutput(out,
        "Before sorting " + label + " (n = " + to_string(n) + ")",
        working);

    resetCounters();
    quickSort(working, 0, working.size() - 1, comp);

    writeOutput(out,
        "After sorting " + label + " (n = " + to_string(n) + ")",
        working);

    return {numComparisons, numAssignments};
}

void writeResults(ofstream& out,
                  bool& headerWritten,
                  const int n,
                  double avgComp,
                  double avgAssn) {

    if (!headerWritten) {
        out << "N,Avg_Comparisons,Avg_Assignments\n";
        headerWritten = true;
    }

    out << n << "," << avgComp << "," << avgAssn << "\n";
}

int randomIndex(const int max) {
    static mt19937 rng(random_device{}());
    uniform_int_distribution<int> dist(0, max - 1);
    return dist(rng);
}

/* ===================== EXPERIMENT ===================== */

void performExperiment(const vector<Person>& allRecords,
                       const int n,
                       ofstream& ageSorted,
                       ofstream& nameSorted,
                       ofstream& ageNameSorted,
                       ofstream& resAge,
                       ofstream& resName,
                       ofstream& resAgeName,
                       bool& ageHeader,
                       bool& nameHeader,
                       bool& ageNameHeader) {

    double ageC = 0, ageA = 0;
    double nameC = 0, nameA = 0;
    double ageNameC = 0, ageNameA = 0;

    for (int i = 0; i < 10; ++i) {

        vector<Person> dataset;

        for (int j = 0; j < n; ++j) {
            dataset.push_back(
                allRecords[randomIndex(allRecords.size())]
            );
        }

        auto [c1, a1] = runSortAndWrite(dataset, n, "by age",
                                        compareByAge, ageSorted);

        auto [c2, a2] = runSortAndWrite(dataset, n, "by name",
                                        compareByName, nameSorted);

        auto [c3, a3] = runSortAndWrite(dataset, n, "by age then name",
                                        compareByAgeThenName, ageNameSorted);

        ageC += c1;      ageA += a1;
        nameC += c2;     nameA += a2;
        ageNameC += c3;  ageNameA += a3;
    }

    writeResults(resAge, ageHeader, n, ageC / 10, ageA / 10);
    writeResults(resName, nameHeader, n, nameC / 10, nameA / 10);
    writeResults(resAgeName, ageNameHeader, n,
                 ageNameC / 10, ageNameA / 10);
}

/* ===================== MAIN ===================== */

int main() {

    vector<Person> allRecords = loadDataFromFile("input.csv");

    if (allRecords.empty()) {
        cerr << "Input file has no data\n";
        return 1;
    }

    ofstream ageSorted("ageSorted_output.txt", ios::app);
    ofstream nameSorted("nameSorted_output.txt", ios::app);
    ofstream ageNameSorted("ageNameSorted_output.txt", ios::app);

    ofstream resultsAge("results_age_quick.csv");
    ofstream resultsName("results_name_quick.csv");
    ofstream resultsAgeName("results_age_name_quick.csv");

    bool ageHeader = false;
    bool nameHeader = false;
    bool ageNameHeader = false;

    for (int n = 10; n <= 100; n += 10) {
        performExperiment(allRecords, n,
                          ageSorted, nameSorted, ageNameSorted,
                          resultsAge, resultsName, resultsAgeName,
                          ageHeader, nameHeader, ageNameHeader);
    }

    return 0;
}