import pandas as pd
import matplotlib.pyplot as plt

# -------- AGE --------
age_ins = pd.read_csv("results_age.csv")
age_mer = pd.read_csv("results_age_merge.csv")
age_qui = pd.read_csv("results_age_quick.csv")

plt.figure()
plt.plot(age_ins['N'], age_ins['Avg_Comparisons'], label='Insertion')
plt.plot(age_mer['N'], age_mer['Avg_Comparisons'], label='Merge')
plt.plot(age_qui['N'], age_qui['Avg_Comparisons'], label='Quick')

plt.xlabel("N")
plt.ylabel("Comparisons")
plt.title("Sorting Comparison (Age)")
plt.legend()
plt.grid()

plt.savefig("comparison_age.png")
plt.close()


# -------- NAME --------
name_ins = pd.read_csv("results_name.csv")
name_mer = pd.read_csv("results_name_merge.csv")
name_qui = pd.read_csv("results_name_quick.csv")

plt.figure()
plt.plot(name_ins['N'], name_ins['Avg_Comparisons'], label='Insertion')
plt.plot(name_mer['N'], name_mer['Avg_Comparisons'], label='Merge')
plt.plot(name_qui['N'], name_qui['Avg_Comparisons'], label='Quick')

plt.xlabel("N")
plt.ylabel("Comparisons")
plt.title("Sorting Comparison (Name)")
plt.legend()
plt.grid()

plt.savefig("comparison_name.png")
plt.close()


# -------- AGE + NAME --------
age_name_ins = pd.read_csv("results_age_name.csv")
age_name_mer = pd.read_csv("results_age_name_merge.csv")
age_name_qui = pd.read_csv("results_age_name_quick.csv")

plt.figure()
plt.plot(age_name_ins['N'], age_name_ins['Avg_Comparisons'], label='Insertion')
plt.plot(age_name_mer['N'], age_name_mer['Avg_Comparisons'], label='Merge')
plt.plot(age_name_qui['N'], age_name_qui['Avg_Comparisons'], label='Quick')

plt.xlabel("N")
plt.ylabel("Comparisons")
plt.title("Sorting Comparison (Age + Name)")
plt.legend()
plt.grid()

plt.savefig("comparison_age_name.png")
plt.close()

print("Graphs saved as PNG files.")