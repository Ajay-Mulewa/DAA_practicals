#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

struct WeatherRecord {
    string date;
    string city;
    string state;
    double minTemp;
};

string cleanToken(string s) {
    if (!s.empty() && s.front() == '"') s.erase(0, 1);
    if (!s.empty() && s.back() == '"') s.pop_back();

    size_t start = s.find_first_not_of(" \t");
    size_t end   = s.find_last_not_of(" \t");

    if (start == string::npos) return "";
    return s.substr(start, end - start + 1);
}

bool parseDouble(const string& s, double& value) {
    stringstream ss(s);
    ss >> value;
    return !ss.fail();
}

vector<WeatherRecord> loadData(const string& fileName) {
    vector<WeatherRecord> data;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "Cannot open weather.csv\n";
        return data;
    }

    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {

        string token, date, city, state;
        double minTemp = 0.0;
        bool validTemp = false;

        stringstream ss(line);
        int col = 0;

        while (getline(ss, token, ',')) {
            token = cleanToken(token);

            if (col == 1) date = token;
            if (col == 5) city = token;
            if (col == 8) state = token;
            if (col == 11) validTemp = parseDouble(token, minTemp);

            col++;
        }

        if (!city.empty() && validTemp) {
            data.push_back({date, city, state, minTemp});
        }
    }

    return data;
}

bool comesBefore(const WeatherRecord& a,
                 const WeatherRecord& b) {
    if (a.minTemp < b.minTemp) return true;
    if (a.minTemp > b.minTemp) return false;
    return a.city < b.city;
}

int partition(vector<WeatherRecord>& arr, int low, int high) {

    WeatherRecord pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {

        comparisons++;
        if (comesBefore(arr[j], pivot)) {
            i++;
            swap(arr[i], arr[j]);
            assignments += 3;
        }
    }

    swap(arr[i + 1], arr[high]);
    assignments += 3;

    return i + 1;
}

void quickSort(vector<WeatherRecord>& arr, int low, int high) {

    if (low < high) {

        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void writeToFile(const vector<WeatherRecord>& data,
                 const string& outFile) {

    ofstream out(outFile);
    out << "Date,City,State,MinTemp\n";

    for (const auto& r : data) {
        out << r.date << ","
            << r.city << ","
            << r.state << ","
            << r.minTemp << "\n";
    }
}

int main() {

    string inputFile  = "weather.csv";
    string outputFile = "weather_sorted_simple.csv";

    vector<WeatherRecord> data = loadData(inputFile);

    if (data.empty()) {
        cerr << "No valid records found.\n";
        return 1;
    }

    mergeSort(data, 0, data.size() - 1);

    writeToFile(data, outputFile);

    cout << "Sorting completed successfully.\n";

    return 0;
}