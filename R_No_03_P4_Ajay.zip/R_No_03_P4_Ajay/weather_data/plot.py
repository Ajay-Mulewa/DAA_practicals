import pandas as pd
import matplotlib.pyplot as plt

# Load data
ins = pd.read_csv("results_temp_insertion.csv")
mer = pd.read_csv("results_weather_merge.csv")
qui = pd.read_csv("results_weather_quick.csv")

# -------- Comparisons --------
plt.figure()
plt.plot(ins['N'], ins['Avg_Comparisons'], label='Insertion')
plt.plot(mer['N'], mer['Avg_Comparisons'], label='Merge')
plt.plot(qui['N'], qui['Avg_Comparisons'], label='Quick')

plt.xlabel("N")
plt.ylabel("Comparisons")
plt.title("Weather Data Sorting Comparison")
plt.legend()
plt.grid()

plt.savefig("weather_all_comparison.png")
plt.close()


# -------- Assignments --------
plt.figure()
plt.plot(ins['N'], ins['Avg_Assignments'], label='Insertion')
plt.plot(mer['N'], mer['Avg_Assignments'], label='Merge')
plt.plot(qui['N'], qui['Avg_Assignments'], label='Quick')

plt.xlabel("N")
plt.ylabel("Assignments")
plt.title("Weather Data Assignment Comparison")
plt.legend()
plt.grid()

plt.savefig("weather_all_assignments.png")
plt.close()

print("Graphs saved successfully.")